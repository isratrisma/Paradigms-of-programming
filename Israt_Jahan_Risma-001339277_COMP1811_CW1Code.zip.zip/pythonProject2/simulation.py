import random

import time
#F2:number of item and the basket size:
class Customer:

    counter = 1

    def __init__(self):

        self.name = f"C{Customer.counter}"

        Customer.counter += 1

        self.basket_size = random.randint(1, 30)

        self.lottery_ticket = self.award_lottery_ticket()


    def get_basket_size(self):

        return self.basket_size


#F2:Getting the checkout time:
    def get_checkout_time(self, self_service ):

        time = 6 if self_service else 4

        return self.basket_size * time


#F2:Award a lottery ticket :
    def award_lottery_ticket(self):

        return self.basket_size >= 10 and random.choice([True, False])



    def display_customer_details(self):

        lottery_status = 'wins a lottery ticket!' if self.lottery_ticket else 'hard luck, no lottery ticket this time!'

        print(f"{self.name} —> items in basket: {self.basket_size}, "

              f"Lottery Status: {lottery_status} "

              f"time to process basket at {'self-service' if self.lottery_ticket else 'cashier'} till: "

              f"{self.get_checkout_time(self.lottery_ticket)} Secs")



    @classmethod

    def reset_counter(cls):

        cls.counter = 1


#F1: generating a lane:
class CheckoutLane(Customer):

    def __init__(self, name, lanetype, capacity):
        super().__init__()


        self.name = name

        self.lanetype = lanetype

        self.capacity = capacity

        self.status = 'closed'

        self.timestamp = None

        self.customers = []
        self.last_updated_time = None


    def is_full(self):

        return len(self.customers) >= self.capacity


#F1:Adding customers to a lane:
    def add_customer(self, customer):

        self.customers.append(customer)


#F1:removing customer:
    def remove_customer(self, customer):

        self.customers.remove(customer)
#F1:open a lane:
    def open_lane(self):

        if self.status == 'closed':

            self.status = 'open'

            self.timestamp = time.strftime("%H:%M:%S")

            self.last_updated_time = self.timestamp

#F1:close a lane:
    def close_lane(self):

        if self.status == 'open':

            self.status = 'closed'

            self.timestamp = None

            self.last_updated_time = time.strftime("%H:%M:%S")

#F1:Display lane status:
    def display_status(self):

        print(f"{self.name} ({'Reg' if self.lanetype == 'regular' else 'Slf'}) —> "

              f"{' '.join('*' for _ in range(len(self.customers))) if self.status == 'open' else 'closed'}")

#f3
class SupermarketSimulation:


    def __init__(self, max_customers=40):

        self.regular_lanes = [CheckoutLane(f"L{i}", 'regular', 5) for i in range(1, 6)]

        self.self_service_lane = CheckoutLane("L6", 'self-service', 15)

        self.lanes = self.regular_lanes + [self.self_service_lane]

        self.customers_waiting = []

    def reset_simulation(self):

        self.customers_waiting = []

        Customer.reset_counter()  # Reset the customer counter

        for lane in self.lanes:

            lane.status = 'closed'

            lane.timestamp = None

            lane.customers = []

            lane.last_updated_time = None
#F2:generate a customer:
    def generate_customer(self):

        return Customer()


    def generate_initial_customers(self):

        num_initial_customers = random.randint(1, 10)

        return [self.generate_customer() for _ in range(num_initial_customers)]


    def assign_customer_to_lane(self, customer):

        if customer.get_basket_size() < 10 and not self.self_service_lane.is_full():

            self.self_service_lane.add_customer(customer)

        else:

            available_lanes = [lane for lane in self.regular_lanes if not lane.is_full()]

            if available_lanes:

                shortest_lane = min(available_lanes, key=lambda lane: len(lane.customers))

                shortest_lane.add_customer(customer)

            else:

                print("All lanes are full. Unable to assign customer.")

    def open_new_lane(self):

        if all(lane.is_full() for lane in self.lanes):

            print("All lanes are full. Unable to open a new lane.")

        else:

            for lane in self.lanes:

                lane.open_lane()
#F1:
    def close_empty_lanes(self):

        for lane in self.lanes:

            if lane.status == 'open' and not lane.customers:

                lane.close_lane()
#F3:
    def display_simulation_status(self):

        total_customers_waiting = sum(len(lane.customers) for lane in self.lanes if lane.status == 'open')

        print(

            f"Total number of customers waiting to check out at {time.strftime('%H:%M:%S')} is: {total_customers_waiting}")

        for lane in self.lanes:

            lane.display_status()
#F2:
    def display_lottery_info(self):

        for customer in self.customers_waiting:

            customer.display_customer_details()
#F3:
    def run_simulation(self, max_duration):

        # Run the simulation loop

        start_time = time.time()

        while time.time() - start_time < max_duration:


            self.reset_simulation()

            initial_customers = self.generate_initial_customers()

            self.customers_waiting.extend(initial_customers)



            for customer in initial_customers:

                self.assign_customer_to_lane(customer)



            new_customer = self.generate_customer()

            self.customers_waiting.append(new_customer)

            self.assign_customer_to_lane(new_customer)

            self.open_new_lane()

            self.close_empty_lanes()

            self.display_simulation_status()

            self.display_lottery_info()
            time.sleep(30)    # Simulate 30-second intervals


if __name__ == "__main__":

    simulation = SupermarketSimulation(max_customers=40)

    simulation.display_simulation_status()

    simulation.display_lottery_info()

    simulation.run_simulation(150)
